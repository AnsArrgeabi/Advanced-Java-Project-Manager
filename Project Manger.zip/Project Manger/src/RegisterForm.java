import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.regex.Pattern;

public class RegisterForm extends JFrame {
    private JTextField fullNameField, emailField, usernameField;
    private JPasswordField passwordField;

    public RegisterForm() {
        setTitle("Professional Registration");
        setSize(500, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Full Name
        panel.add(new JLabel("Full Name:"));
        fullNameField = new JTextField();
        panel.add(fullNameField);

        // Email
        panel.add(new JLabel("Email:"));
        emailField = new JTextField();
        panel.add(emailField);

        // Username
        panel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        panel.add(usernameField);

        // Password
        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        // Register Button
        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(this::handleRegister);
        panel.add(registerButton);

        // Back Button
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            new LoginForm().setVisible(true);
            dispose();
        });
        panel.add(backButton);

        add(panel);
    }

    private void handleRegister(ActionEvent e) {
        String fullName = fullNameField.getText().trim();
        String email = emailField.getText().trim();
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        // Input Validation
        if (fullName.isEmpty() || email.isEmpty() || username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "❌ All fields are required!");
            return;
        }

        if (!isValidEmail(email)) {
            JOptionPane.showMessageDialog(this, "❌ Invalid email format!");
            return;
        }

        if (password.length() < 8) {
            JOptionPane.showMessageDialog(this, "❌ Password must be at least 8 characters!");
            return;
        }

        // Registration
        User newUser = new User(username, password, fullName, email);
        if (UserDAO.registerUser(newUser)) {
            int choice = JOptionPane.showConfirmDialog(
                this,
                "✅ Registration successful!\nGo to login page?",
                "Success",
                JOptionPane.YES_NO_OPTION
            );
            if (choice == JOptionPane.YES_OPTION) {
                new LoginForm().setVisible(true);
                dispose();
            }
        }
    }

    private boolean isValidEmail(String email) {
        String regex = "^[A-Za-z0-9+_.-]+@(.+)$";
        return Pattern.compile(regex).matcher(email).matches();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RegisterForm().setVisible(true));
    }
}