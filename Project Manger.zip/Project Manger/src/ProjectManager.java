import javax.swing.*;

public class ProjectManager {
    public static void main(String[] args) {
        // Optional: Set system look and feel for a cleaner native appearance
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            System.out.println("Unable to set Look & Feel: " + e.getMessage());
        }

        // Launch the Login Form
        SwingUtilities.invokeLater(() -> {
            LoginForm loginForm = new LoginForm();
            loginForm.setVisible(true);
        });
    }
}






