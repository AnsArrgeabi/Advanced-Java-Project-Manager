import java.util.Date;

public class Task {
    private int id;
    private int projectId;
    private String title;
    private String status;
    private Date dueDate;

    // Constructors
    public Task() {} // Required for DAO operations

    public Task(int id, int projectId, String title) {
        this.id = id;
        this.projectId = projectId;
        this.title = title;
        this.status = "Pending"; // Default status
    }

    public Task(int projectId, String title) {
        this.projectId = projectId;
        this.title = title;
        this.status = "Pending";
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getProjectId() { return projectId; }
    public void setProjectId(int projectId) { this.projectId = projectId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Date getDueDate() { return dueDate; }
    public void setDueDate(Date dueDate) { this.dueDate = dueDate; }
}