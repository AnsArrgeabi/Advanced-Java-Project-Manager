import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginForm extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginForm() {
        setTitle("Login");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Center panel for inputs and buttons
        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));

        // Username
        formPanel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        formPanel.add(usernameField);

        // Password
        formPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        formPanel.add(passwordField);

        // Login Button
        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(this::handleLogin);
        formPanel.add(loginButton);

        // Register Button
        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(e -> {
            new RegisterForm().setVisible(true);
            dispose();
        });
        formPanel.add(registerButton);

        add(formPanel, BorderLayout.CENTER);

        // Bottom panel with centered Exit button
        JPanel exitPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(e -> System.exit(0));
        exitPanel.add(exitButton);
        add(exitPanel, BorderLayout.SOUTH);
    }

    private void handleLogin(ActionEvent e) {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "❌ Username and password are required!");
            return;
        }

        User user = UserDAO.loginUser(username, password);
        if (user != null) {
            JOptionPane.showMessageDialog(this, "✅ Welcome, " + user.getFullName() + "!");
            dispose();
            new Dashboard(user).setVisible(true); // open dashboard on success
        } else {
            JOptionPane.showMessageDialog(this, "❌ Invalid credentials. Please register.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginForm().setVisible(true));
    }
}
