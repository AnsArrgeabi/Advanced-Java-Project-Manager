import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ProjectDAO {

    public static boolean addProject(Project project) {
        String sql = "INSERT INTO projects (user_id, title, description) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, project.getUserId());
            stmt.setString(2, project.getTitle());
            stmt.setString(3, project.getDescription());

            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows > 0) {
                // Get the generated project ID (for future task relationships)
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        project.setId(rs.getInt(1));
                    }
                }
                return true;
            }
            return false;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, 
                "❌ Failed to add project: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public static List<Project> getProjectsByUser(int userId) {
        List<Project> projects = new ArrayList<>();
        String sql = "SELECT title, description FROM projects WHERE user_id = ? ORDER BY title";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Project p = new Project(
                    userId, // We only store user_id since we're not showing project ID
                    rs.getString("title"),
                    rs.getString("description")
                );
                projects.add(p);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, 
                "❌ Failed to load projects: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }

        return projects;
    }

    public static boolean updateProject(Project project) {
        String sql = "UPDATE projects SET title = ?, description = ? WHERE title = ? AND user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, project.getTitle());
            stmt.setString(2, project.getDescription());
            stmt.setString(3, project.getTitle()); // Original title for WHERE clause
            stmt.setInt(4, project.getUserId());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, 
                "❌ Failed to update project: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public static boolean deleteProject(String projectTitle, int userId) {
        String sql = "DELETE FROM projects WHERE title = ? AND user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, projectTitle);
            stmt.setInt(2, userId);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, 
                "❌ Failed to delete project: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    // Helper method to get project ID by title (for task relationships)
    public static int getProjectId(String title, int userId) {
        String sql = "SELECT id FROM projects WHERE title = ? AND user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, title);
            stmt.setInt(2, userId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("id");
            }
            return -1;

        } catch (SQLException e) {
            return -1;
        }
    }
}