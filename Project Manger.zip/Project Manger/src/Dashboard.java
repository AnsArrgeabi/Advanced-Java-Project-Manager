import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;

public class Dashboard extends JFrame {
    private User currentUser;
    private JTable projectTable;
    private DefaultTableModel tableModel;
    private JPanel taskPanel;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public Dashboard(User user) {
        this.currentUser = user;
        setTitle("Project Manager - " + currentUser.getFullName());
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(400);

        JPanel projectsPanel = createProjectsPanel();
        splitPane.setLeftComponent(projectsPanel);

        taskPanel = new JPanel(new BorderLayout());
        taskPanel.setBorder(new CompoundBorder(
                new TitledBorder("Project Tasks"),
                new EmptyBorder(10, 10, 10, 10)
        ));
        taskPanel.add(new JLabel("Select a project to view tasks"), BorderLayout.CENTER);
        splitPane.setRightComponent(taskPanel);

        add(splitPane, BorderLayout.CENTER);

        loadProjects();
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(30, 50, 80));
        panel.setBorder(new EmptyBorder(20, 30, 20, 30));

        JLabel nameLabel = new JLabel(currentUser.getFullName());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        nameLabel.setForeground(Color.WHITE);

        JLabel emailLabel = new JLabel(currentUser.getEmail());
        emailLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        emailLabel.setForeground(new Color(200, 200, 200));

        JPanel infoPanel = new JPanel(new GridLayout(2, 1, 0, 5));
        infoPanel.setOpaque(false);
        infoPanel.add(nameLabel);
        infoPanel.add(emailLabel);

        panel.add(infoPanel, BorderLayout.WEST);

        JButton logoutBtn = createStyledButton("Logout", new Color(200, 60, 60));
        logoutBtn.addActionListener(e -> {
            new LoginForm().setVisible(true);
            dispose();
        });

        JPanel buttonWrapper = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonWrapper.setOpaque(false);
        buttonWrapper.add(logoutBtn);
        panel.add(buttonWrapper, BorderLayout.EAST);

        return panel;
    }

    private JPanel createProjectsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new CompoundBorder(
                new TitledBorder("Your Projects"),
                new EmptyBorder(10, 10, 10, 10)
        ));

        tableModel = new DefaultTableModel(new Object[]{"Title", "Description"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        projectTable = new JTable(tableModel);
        projectTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        projectTable.setRowHeight(35);
        projectTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        projectTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        projectTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) showProjectTasks();
        });

        panel.add(new JScrollPane(projectTable), BorderLayout.CENTER);
        panel.add(createProjectButtons(), BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createProjectButtons() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        panel.setBorder(new EmptyBorder(10, 0, 0, 0));

        JButton addBtn = createStyledButton("Add Project", new Color(70, 130, 180));
        JButton editBtn = createStyledButton("Edit Project", new Color(70, 130, 180));
        JButton deleteBtn = createStyledButton("Delete", new Color(200, 60, 60));
        JButton exportBtn = createStyledButton("Export Projects", new Color(34, 139, 34));

        addBtn.addActionListener(e -> addProject());
        editBtn.addActionListener(e -> editProject());
        deleteBtn.addActionListener(e -> deleteProject());
        exportBtn.addActionListener(e -> exportProjectsToFile());

        panel.add(addBtn);
        panel.add(editBtn);
        panel.add(deleteBtn);
        panel.add(exportBtn);

        return panel;
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setBorder(new EmptyBorder(8, 15, 8, 15));
        return btn;
    }

    private void loadProjects() {
        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() {
                tableModel.setRowCount(0);
                List<Project> projects = ProjectDAO.getProjectsByUser(currentUser.getId());
                for (Project p : projects) {
                    tableModel.addRow(new Object[]{p.getTitle(), p.getDescription()});
                }
                return null;
            }
        };
        worker.execute();
    }

    private void showProjectTasks() {
        int row = projectTable.getSelectedRow();
        if (row >= 0) {
            String projectTitle = (String) tableModel.getValueAt(row, 0);
            int projectId = ProjectDAO.getProjectId(projectTitle, currentUser.getId());

            taskPanel.removeAll();
            JPanel tasksListPanel = new JPanel();
            tasksListPanel.setLayout(new BoxLayout(tasksListPanel, BoxLayout.Y_AXIS));

            List<Task> tasks = TaskDAO.getTasksByProject(projectId);
            for (Task task : tasks) {
                tasksListPanel.add(createTaskItem(task));
            }

            JScrollPane scrollPane = new JScrollPane(tasksListPanel);
            taskPanel.add(scrollPane, BorderLayout.CENTER);
            taskPanel.add(createAddTaskPanel(projectId), BorderLayout.SOUTH);

            taskPanel.revalidate();
            taskPanel.repaint();
        }
    }

    private JPanel createTaskItem(Task task) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(5, 5, 5, 5));

        String dueText = task.getDueDate() != null ?
                " (Due: " + dateFormat.format(task.getDueDate()) + ")" : "";

        JCheckBox taskCheckbox = new JCheckBox(task.getTitle() + dueText);
        taskCheckbox.setSelected("Completed".equals(task.getStatus()));
        taskCheckbox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        taskCheckbox.addActionListener(e -> {
            String newStatus = taskCheckbox.isSelected() ? "Completed" : "Pending";
            TaskDAO.updateTaskStatus(task.getId(), newStatus);
        });

        JButton deleteBtn = new JButton("✕");
        deleteBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        deleteBtn.setForeground(Color.RED);
        deleteBtn.setBorderPainted(false);
        deleteBtn.setContentAreaFilled(false);
        deleteBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to delete this task?\n" + task.getTitle(),
                    "Confirm Task Deletion",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );
            if (confirm == JOptionPane.YES_OPTION) {
                if (TaskDAO.deleteTask(task.getId())) {
                    showProjectTasks();
                }
            }
        });

        panel.add(taskCheckbox, BorderLayout.CENTER);
        panel.add(deleteBtn, BorderLayout.EAST);
        return panel;
    }

    private JPanel createAddTaskPanel(int projectId) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));

        JTextField taskField = new JTextField();
        JTextField dateField = new JTextField(10);
        dateField.setToolTipText("Format: YYYY-MM-DD");

        JLabel dateLabel = new JLabel("Due Date (YYYY-MM-DD):");
        JButton dateHelpBtn = new JButton("?");
        dateHelpBtn.setMargin(new Insets(2, 5, 2, 5));
        dateHelpBtn.addActionListener(e ->
                JOptionPane.showMessageDialog(this,
                        "Please enter the due date in this format:\nYYYY-MM-DD\nExample: 2025-06-30",
                        "Date Format Help",
                        JOptionPane.INFORMATION_MESSAGE)
        );

        JPanel datePanel = new JPanel(new BorderLayout(5, 5));
        datePanel.add(dateField, BorderLayout.CENTER);
        datePanel.add(dateHelpBtn, BorderLayout.EAST);

        JButton addBtn = createStyledButton("Add Task", new Color(70, 130, 180));
        addBtn.addActionListener(e -> {
            String taskName = taskField.getText().trim();
            if (taskName.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Task name cannot be empty.", "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Date dueDate = null;
            try {
                String dateText = dateField.getText().trim();
                if (!dateText.isEmpty()) {
                    dueDate = dateFormat.parse(dateText);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid date format. Please use YYYY-MM-DD.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Task newTask = new Task(projectId, taskName);
            newTask.setDueDate(dueDate);

            if (TaskDAO.addTask(newTask)) {
                taskField.setText("");
                dateField.setText("");
                showProjectTasks();
            }
        });

        JPanel inputPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        inputPanel.add(new JLabel("Task Title:"));
        inputPanel.add(taskField);
        inputPanel.add(dateLabel);
        inputPanel.add(datePanel);

        panel.add(inputPanel, BorderLayout.CENTER);
        panel.add(addBtn, BorderLayout.EAST);

        return panel;
    }

    private void addProject() {
        JPanel inputPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        inputPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JTextField titleField = new JTextField();
        JTextArea descArea = new JTextArea(3, 20);
        descArea.setLineWrap(true);

        inputPanel.add(new JLabel("Title:"));
        inputPanel.add(titleField);
        inputPanel.add(new JLabel("Description:"));
        inputPanel.add(new JScrollPane(descArea));

        int result = JOptionPane.showConfirmDialog(
                this, inputPanel, "Add New Project",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION && !titleField.getText().trim().isEmpty()) {
            Project p = new Project(
                    currentUser.getId(),
                    titleField.getText().trim(),
                    descArea.getText().trim()
            );
            if (ProjectDAO.addProject(p)) {
                loadProjects();
            }
        }
    }

    private void editProject() {
        int row = projectTable.getSelectedRow();
        if (row >= 0) {
            String currentTitle = (String) tableModel.getValueAt(row, 0);
            String currentDesc = (String) tableModel.getValueAt(row, 1);

            JPanel inputPanel = new JPanel(new GridLayout(2, 2, 10, 10));
            inputPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

            JTextField titleField = new JTextField(currentTitle);
            JTextArea descArea = new JTextArea(currentDesc);
            descArea.setLineWrap(true);

            inputPanel.add(new JLabel("Title:"));
            inputPanel.add(titleField);
            inputPanel.add(new JLabel("Description:"));
            inputPanel.add(new JScrollPane(descArea));

            int result = JOptionPane.showConfirmDialog(
                    this, inputPanel, "Edit Project",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE
            );

            if (result == JOptionPane.OK_OPTION && !titleField.getText().trim().isEmpty()) {
                Project p = new Project(
                        currentUser.getId(),
                        titleField.getText().trim(),
                        descArea.getText().trim()
                );
                if (ProjectDAO.updateProject(p)) {
                    loadProjects();
                }
            }
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a project to edit",
                    "No Selection",
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }

    private void deleteProject() {
        int row = projectTable.getSelectedRow();
        if (row >= 0) {
            String projectTitle = (String) tableModel.getValueAt(row, 0);

            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Delete project '" + projectTitle + "' and all its tasks?",
                    "Confirm Deletion",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );

            if (confirm == JOptionPane.YES_OPTION) {
                if (ProjectDAO.deleteProject(projectTitle, currentUser.getId())) {
                    loadProjects();
                    taskPanel.removeAll();
                    taskPanel.add(new JLabel("Select a project to view tasks"));
                    taskPanel.revalidate();
                    taskPanel.repaint();
                }
            }
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a project to delete",
                    "No Selection",
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }

    private void exportProjectsToFile() {
        List<Project> projects = ProjectDAO.getProjectsByUser(currentUser.getId());
        if (projects.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No projects to export.", "Export Projects", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        try {
            File file = new File("projects_export.txt");
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                for (Project p : projects) {
                    writer.write("Title: " + p.getTitle());
                    writer.newLine();
                    writer.write("Description: " + p.getDescription());
                    writer.newLine();
                    writer.write("------------------------------------");
                    writer.newLine();
                }
            }
            JOptionPane.showMessageDialog(this, "Projects exported successfully to:\n" + file.getAbsolutePath(), "Export Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error exporting projects: " + e.getMessage(), "Export Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
