import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class TaskDAO {
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MMM dd, yyyy");

    public static boolean addTask(Task task) {
        if (task == null || task.getTitle() == null || task.getTitle().trim().isEmpty()) {
            showError("Task title cannot be empty");
            return false;
        }

        String sql = "INSERT INTO tasks (project_id, title, status, due_date) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, task.getProjectId());
            stmt.setString(2, task.getTitle().trim());
            stmt.setString(3, task.getStatus() != null ? task.getStatus() : "Pending");
            
            if (task.getDueDate() != null) {
                stmt.setDate(4, new java.sql.Date(task.getDueDate().getTime()));
            } else {
                stmt.setNull(4, Types.DATE);
            }

            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        task.setId(rs.getInt(1));
                    }
                }
                return true;
            }
            return false;
            
        } catch (SQLException e) {
            showError("Failed to add task to database: " + e.getMessage());
            return false;
        }
    }

    public static List<Task> getTasksByProject(int projectId) {
        List<Task> tasks = new ArrayList<>();
        String sql = "SELECT id, title, status, due_date FROM tasks WHERE project_id = ? ORDER BY " +
                     "CASE WHEN due_date IS NULL THEN 1 ELSE 0 END, due_date ASC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, projectId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Task task = new Task();
                task.setId(rs.getInt("id"));
                task.setProjectId(projectId);
                task.setTitle(rs.getString("title"));
                task.setStatus(rs.getString("status"));
                task.setDueDate(rs.getDate("due_date"));
                tasks.add(task);
            }
        } catch (SQLException e) {
            showError("Failed to load tasks from database: " + e.getMessage());
        }
        return tasks;
    }

    public static boolean updateTaskStatus(int taskId, String newStatus) {
        if (newStatus == null || !(newStatus.equals("Completed") || newStatus.equals("Pending"))) {
            showError("Invalid task status");
            return false;
        }

        String sql = "UPDATE tasks SET status = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, newStatus);
            stmt.setInt(2, taskId);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            showError("Failed to update task status: " + e.getMessage());
            return false;
        }
    }

    public static boolean updateTask(Task task) {
        if (task == null || task.getId() <= 0 || task.getTitle() == null || task.getTitle().trim().isEmpty()) {
            showError("Invalid task data");
            return false;
        }

        String sql = "UPDATE tasks SET title = ?, status = ?, due_date = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, task.getTitle().trim());
            stmt.setString(2, task.getStatus() != null ? task.getStatus() : "Pending");
            
            if (task.getDueDate() != null) {
                stmt.setDate(3, new java.sql.Date(task.getDueDate().getTime()));
            } else {
                stmt.setNull(3, Types.DATE);
            }
            
            stmt.setInt(4, task.getId());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            showError("Failed to update task: " + e.getMessage());
            return false;
        }
    }

    public static boolean deleteTask(int taskId) {
        String sql = "DELETE FROM tasks WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, taskId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            showError("Failed to delete task: " + e.getMessage());
            return false;
        }
    }

    public static String formatDueDate(Date date) {
        if (date == null) return "No deadline";
        synchronized (DATE_FORMAT) {
            return DATE_FORMAT.format(date);
        }
    }

    private static void showError(String message) {
        // Simple version without SwingUtilities
        JOptionPane.showMessageDialog(
            null, 
            "❌ " + message, 
            "Task Error", 
            JOptionPane.ERROR_MESSAGE
        );
    }
}